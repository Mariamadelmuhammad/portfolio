import React from "react";
import "./Portfolio.css";
import img1 from "../../media/img1.jpg";
import img2 from "../../media/img2.jpg";
import img3 from "../../media/img3.jpg";
import img4 from "../../media/img4.jpg";
import img5 from "../../media/img5.jpg";
import img6 from "../../media/img6.jpg";

export default function Portfolio() {
  const data = [
    {
      id: 1,
      image: img1,
      title: "lorem ipsum",
      github: "https://github.com",
    },
    {
      id: 2,
      image: img2,
      title: "lorem ipsum",
      github: "https://github.com",
    },
    {
      id: 3,
      image: img3,
      title: "lorem ipsum",
      github: "https://github.com",
    },
    {
      id: 4,
      image: img4,
      title: "lorem ipsum",
      github: "https://github.com",
    },
    {
      id: 5,
      image: img5,
      title: "lorem ipsum",
      github: "https://github.com",
    },
    {
      id: 6,
      image: img6,
      title: "lorem ipsum",
      github: "https://github.com",
    },
  ];
  return (
    <section id="portfolio">
      <h5>My Recent Work</h5>
      <h2>portfolio</h2>
      <div className="container portfolio__container">
        {data.map(({ id, image, title, github }) => {
          return (
            <article className="portfolio__item" key={id}>
              <div className="portfolio__item-image">
                {/* <img src={image} alt={title} /> */}
                <div
                  id="carouselExampleIndicators"
                  className="carousel slide"
                  data-ride="carousel"
                >
                  <ol className="carousel-indicators">
                    <li
                      data-target="#carouselExampleIndicators"
                      data-slide-to="0"
                      className="active"
                    ></li>
                    <li
                      data-target="#carouselExampleIndicators"
                      data-slide-to="1"
                    ></li>
                    <li
                      data-target="#carouselExampleIndicators"
                      data-slide-to="2"
                    ></li>
                  </ol>
                  <div className="carousel-inner">
                    <div className="carousel-item active">
                      <img className="d-block w-100" src={image} alt={title} />
                    </div>
                    <div className="carousel-item">
                      <img className="d-block w-100" src={image} alt={title} />
                    </div>
                    <div className="carousel-item">
                      <img className="d-block w-100" src={image} alt={title} />
                    </div>
                  </div>
                  <a
                    className="carousel-control-prev"
                    href="#carouselExampleIndicators"
                    role="button"
                    data-slide="prev"
                  >
                    <span
                      className="carousel-control-prev-icon"
                      aria-hidden="true"
                    ></span>
                    <span className="sr-only">Previous</span>
                  </a>
                  <a
                    className="carousel-control-next"
                    href="#carouselExampleIndicators"
                    role="button"
                    data-slide="next"
                  >
                    <span
                      className="carousel-control-next-icon"
                      aria-hidden="true"
                    ></span>
                    <span className="sr-only">Next</span>
                  </a>
                </div>
              </div>
              <h3>{title}</h3>
              <div className="portfolio__item-cta">
                <a
                  href={github}
                  className="btn btn-primary"
                  target="_blank"
                  id="btngithub"
                >
                  Github
                </a>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
